﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace PDisaster00030482323016
{
    internal class Cidade
    {

        public int IdCidade { get; set; }

        public String Nome { get; set; }

        public String Uf { get; set; }

        public int Populacao { get; set; }


        public DataTable Listar()
        {

            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();

            try
            {

                daCidade = new SqlDataAdapter("SELECT * FROM Cidade ORDER BY NOME", frmPrincipal.conexao);
                //PREENCHENDO OS DADOS NO DATACIDADE - PASSANDO OS DADOS
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);

            }
            catch (Exception)
            {
                throw;
            }

            return dtCidade;

        }


        public int Incluir()
        {
            int retorno = 0;

            try
            {

                SqlCommand myCommand;

                myCommand = new SqlCommand("INSERT INTO Cidade VALUES (@NOME,@UF, @POPULACAO)", frmPrincipal.conexao);

                myCommand.Parameters.Add(new SqlParameter("@NOME", SqlDbType.VarChar));
                myCommand.Parameters.Add(new SqlParameter("@UF", SqlDbType.Char));
                myCommand.Parameters.Add(new SqlParameter("@POPULACAO", SqlDbType.Int));

                myCommand.Parameters["@NOME"].Value = Nome;
                myCommand.Parameters["@UF"].Value = Uf;
                myCommand.Parameters["@POPULACAO"].Value = Populacao;

                retorno = myCommand.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }

            return retorno;
        }


        public int Alterar()
        {
            int retorno = 0;

            try
            {

                SqlCommand myCommand;

                myCommand = new SqlCommand("UPDATE Cidade SET NOME = @NOME, UF=@UF, POPULACAO=@POPULACAO WHERE IDCIDADE=IDCIDADE", frmPrincipal.conexao);

                myCommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int));
                myCommand.Parameters.Add(new SqlParameter("@NOME", SqlDbType.VarChar));
                myCommand.Parameters.Add(new SqlParameter("@UF", SqlDbType.Char));
                myCommand.Parameters.Add(new SqlParameter("@POPULACAO", SqlDbType.Int));

                myCommand.Parameters["@IDCIDADE"].Value = IdCidade;
                myCommand.Parameters["@NOME"].Value = Nome;
                myCommand.Parameters["@UF"].Value = Uf;
                myCommand.Parameters["@POPULACAO"].Value = Populacao;

                retorno =  myCommand.ExecuteNonQuery();

            }catch(Exception)
            {
                throw;
            }

            return retorno;
        }




        public int Excluir()
        {
            int nReg = 0;

            try
            {

                SqlCommand myCommand;

                myCommand = new SqlCommand("DELETE FROM Cidade WHERE IDCIDADE=@IDCIDADE", frmPrincipal.conexao);

                myCommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int));
               
                myCommand.Parameters["@IDCIDADE"].Value = IdCidade;

               nReg = myCommand.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }

            return nReg;
        }

    }

    

}

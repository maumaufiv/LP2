﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PDisaster00030482323016
{
    public partial class frmPrincipal : Form
    {
        //CRIANDO A VARIÁVEL DE CONEXÃO
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //TESTANDO A CONEXÃO DO BANCO DE DADOS
            try
            {
                //CRIANDO A CONEXÃO COM O BANCO DE DADOS
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=LP2;User ID=BD2323011;PASSWORD=Milkklim@13;Encrypt=False");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados" + ex.Message);
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            
            }

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void cadastroTipoEventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmTipo>().Count() > 0)
            {
                Application.OpenForms["frmTipo"].BringToFront();
            }
            else
            {
                frmTipo objFrm2 = new frmTipo();
                objFrm2.MdiParent = this;
                objFrm2.WindowState = FormWindowState.Maximized;
                objFrm2.Show();
            }

        }

        private void cadastroDeCidadesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade objFrm3 = new frmCidade();
                objFrm3.MdiParent = this;
                objFrm3.WindowState = FormWindowState.Maximized;
                objFrm3.Show();
            }
        }

        private void cadastroDeEventosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<frmEvento>().Count() > 0)
            {
                Application.OpenForms["frmEvento"].BringToFront();
            }
            else
            {
                frmEvento objFrm4 = new frmEvento();
                objFrm4.MdiParent = this;
                objFrm4.WindowState = FormWindowState.Maximized;
                objFrm4.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
                {
                    Application.OpenForms["frmSobre"].BringToFront();
                }
                else
                {
                    frmSobre objFrm5 = new frmSobre();
                    objFrm5.MdiParent = this;
                    objFrm5.WindowState = FormWindowState.Maximized;
                    objFrm5.Show();
                }
            }
        }
    }
}

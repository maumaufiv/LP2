﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblfunc = new System.Windows.Forms.Label();
            this.lblsal = new System.Windows.Forms.Label();
            this.lblfilhos = new System.Windows.Forms.Label();
            this.txtFunc = new System.Windows.Forms.TextBox();
            this.mskbxSal = new System.Windows.Forms.MaskedTextBox();
            this.nudFilhos = new System.Windows.Forms.NumericUpDown();
            this.lblNSS = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.txtINSS = new System.Windows.Forms.TextBox();
            this.txtIRPF = new System.Windows.Forms.TextBox();
            this.txtsSalFam = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblfunc
            // 
            this.lblfunc.AutoSize = true;
            this.lblfunc.Location = new System.Drawing.Point(11, 22);
            this.lblfunc.Name = "lblfunc";
            this.lblfunc.Size = new System.Drawing.Size(117, 16);
            this.lblfunc.TabIndex = 0;
            this.lblfunc.Text = "Nome Funcionário";
            // 
            // lblsal
            // 
            this.lblsal.AutoSize = true;
            this.lblsal.Location = new System.Drawing.Point(11, 57);
            this.lblsal.Name = "lblsal";
            this.lblsal.Size = new System.Drawing.Size(84, 16);
            this.lblsal.TabIndex = 1;
            this.lblsal.Text = "Salário Bruto";
            // 
            // lblfilhos
            // 
            this.lblfilhos.AutoSize = true;
            this.lblfilhos.Location = new System.Drawing.Point(11, 96);
            this.lblfilhos.Name = "lblfilhos";
            this.lblfilhos.Size = new System.Drawing.Size(75, 16);
            this.lblfilhos.TabIndex = 2;
            this.lblfilhos.Text = "Nº de filhos";
            // 
            // txtFunc
            // 
            this.txtFunc.Location = new System.Drawing.Point(156, 22);
            this.txtFunc.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFunc.Name = "txtFunc";
            this.txtFunc.Size = new System.Drawing.Size(196, 22);
            this.txtFunc.TabIndex = 3;
            this.txtFunc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFunc_KeyPress);
            // 
            // mskbxSal
            // 
            this.mskbxSal.Location = new System.Drawing.Point(156, 57);
            this.mskbxSal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mskbxSal.Mask = "99000.00";
            this.mskbxSal.Name = "mskbxSal";
            this.mskbxSal.Size = new System.Drawing.Size(196, 22);
            this.mskbxSal.TabIndex = 4;
            this.mskbxSal.Validated += new System.EventHandler(this.mskbxSal_Validated);
            // 
            // nudFilhos
            // 
            this.nudFilhos.Location = new System.Drawing.Point(156, 91);
            this.nudFilhos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nudFilhos.Name = "nudFilhos";
            this.nudFilhos.Size = new System.Drawing.Size(62, 22);
            this.nudFilhos.TabIndex = 5;
            // 
            // lblNSS
            // 
            this.lblNSS.AutoSize = true;
            this.lblNSS.Location = new System.Drawing.Point(11, 190);
            this.lblNSS.Name = "lblNSS";
            this.lblNSS.Size = new System.Drawing.Size(90, 16);
            this.lblNSS.TabIndex = 6;
            this.lblNSS.Text = "Aliquota INSS";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(11, 234);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(89, 16);
            this.lblIRPF.TabIndex = 7;
            this.lblIRPF.Text = "Aliquota IRPF";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Location = new System.Drawing.Point(11, 275);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(97, 16);
            this.lblSalFam.TabIndex = 8;
            this.lblSalFam.Text = "Salário Família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(11, 314);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(97, 16);
            this.lblSalLiq.TabIndex = 9;
            this.lblSalLiq.Text = "Salário Líquido";
            // 
            // txtINSS
            // 
            this.txtINSS.Enabled = false;
            this.txtINSS.Location = new System.Drawing.Point(156, 187);
            this.txtINSS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtINSS.Name = "txtINSS";
            this.txtINSS.Size = new System.Drawing.Size(196, 22);
            this.txtINSS.TabIndex = 12;
            // 
            // txtIRPF
            // 
            this.txtIRPF.Enabled = false;
            this.txtIRPF.Location = new System.Drawing.Point(156, 229);
            this.txtIRPF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIRPF.Name = "txtIRPF";
            this.txtIRPF.Size = new System.Drawing.Size(196, 22);
            this.txtIRPF.TabIndex = 13;
            // 
            // txtsSalFam
            // 
            this.txtsSalFam.Enabled = false;
            this.txtsSalFam.Location = new System.Drawing.Point(156, 270);
            this.txtsSalFam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtsSalFam.Name = "txtsSalFam";
            this.txtsSalFam.Size = new System.Drawing.Size(196, 22);
            this.txtsSalFam.TabIndex = 14;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(156, 312);
            this.txtSalLiq.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(196, 22);
            this.txtSalLiq.TabIndex = 15;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(486, 185);
            this.txtDescINSS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(177, 22);
            this.txtDescINSS.TabIndex = 16;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(485, 229);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(177, 22);
            this.txtDescIRPF.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(374, 185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(374, 234);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(98, 16);
            this.lblDescIRPF.TabIndex = 11;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(226, 129);
            this.btnVerificar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(229, 27);
            this.btnVerificar.TabIndex = 19;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 360);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtsSalFam);
            this.Controls.Add(this.txtIRPF);
            this.Controls.Add(this.txtINSS);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lblNSS);
            this.Controls.Add(this.nudFilhos);
            this.Controls.Add(this.mskbxSal);
            this.Controls.Add(this.txtFunc);
            this.Controls.Add(this.lblfilhos);
            this.Controls.Add(this.lblsal);
            this.Controls.Add(this.lblfunc);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblfunc;
        private System.Windows.Forms.Label lblsal;
        private System.Windows.Forms.Label lblfilhos;
        private System.Windows.Forms.TextBox txtFunc;
        private System.Windows.Forms.MaskedTextBox mskbxSal;
        private System.Windows.Forms.NumericUpDown nudFilhos;
        private System.Windows.Forms.Label lblNSS;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.TextBox txtINSS;
        private System.Windows.Forms.TextBox txtIRPF;
        private System.Windows.Forms.TextBox txtsSalFam;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Button btnVerificar;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double SalBruto, SalFam, SalLiq, DescINSS, DescIRPF, Filhos;

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (SalBruto <= 800.47)
            {
                txtINSS.Text = "7.65%";
                DescINSS = 0.0765 * SalBruto;
            }
            else if (SalBruto <= 1050)
            {
                txtINSS.Text = "8.65%";
                DescINSS = ((8.65 / 100) * SalBruto);
            }
            else if (SalBruto <= 1400.77)
            {
                txtINSS.Text = "9.00%";
                DescINSS = ((9 / 100) * SalBruto);
            }
            else if (SalBruto <= 2801.56)
            {
                txtINSS.Text = "11.00%";
                DescINSS = ((11 / 100) * SalBruto);
            }
            else
            {
                txtINSS.Text = "Teto";
                DescINSS = 308.17;
            }
            if (SalBruto <= 1257.12)
            {
                txtIRPF.Text = "Isento";
                DescIRPF = 0;
            }
            else if (SalBruto <= 2512.08)
            {
                txtIRPF.Text = "15.00%";
                DescIRPF = ((15 / 100) * SalBruto);
            }
            else
            {
                txtIRPF.Text = "27.50%";
                DescIRPF = ((27.50 / 100) * SalBruto);
            }
            Filhos = Convert.ToDouble(nudFilhos.Text);
            if (SalBruto <= 435.52)
            {
                SalFam = 22.33 * Filhos;
            }
            else if (SalBruto <= 654.61)
            {
                SalFam = 15.74 * Filhos;
            }
            else
            {
                SalFam = 0;
            }
            SalLiq = SalBruto - DescINSS - DescIRPF + SalFam;
            txtDescINSS.Text = DescINSS.ToString();
            txtDescIRPF.Text = DescIRPF.ToString();
            txtsSalFam.Text = SalFam.ToString();
            txtSalLiq.Text = SalLiq.ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("caracter inválido"); SendKeys.Send("{BACKSPACE}");
            }
        }

        private void mskbxSal_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxSal.Text, out SalBruto))
            {
                MessageBox.Show("Valor Invalido");
                mskbxSal.Focus();
            }
        }
    }
}

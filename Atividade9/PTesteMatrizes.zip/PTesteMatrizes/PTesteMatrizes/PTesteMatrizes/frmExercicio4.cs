﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            string[] vetor = new string[11];
            string auxiliar;
            int cont = 0;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o Nome {i+1}", "Entrada de Dados");

                if (auxiliar == "")
                {
                    break;
                }
                vetor[i] = auxiliar;

                char[] nome = auxiliar.ToCharArray();
                foreach (char aux in nome)
                {
                   if(char.IsLetter(aux))
                        if (!char.IsWhiteSpace(aux)) 
                        {
                            cont++;
                        }
                   else
                        {
                            MessageBox.Show("Nome Invalido");
                            i--;
                            cont = 0;
                            break;
                        }
                }
                lbNomes.Items.Add($"O nome {auxiliar} tem {cont} letras");
                cont = 0;
            }
        }
    }
}

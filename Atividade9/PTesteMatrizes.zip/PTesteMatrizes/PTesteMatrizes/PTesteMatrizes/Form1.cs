﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º numero", "Entrada de Dados");//Criar INPUTBOX
                
                if(auxiliar == "")
                {
                    break;
                }
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero Invalido");
                    i--;
                }
            }

            auxiliar = "";

            Array.Reverse(vetor);

            foreach(int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }
        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList Alunos = new ArrayList() {"Ana", "Andre", "Debora", "Fatima",
                "João", "Janete", "Otávio", "Marcelo","Pedro", "Thais"};

            Alunos.Remove("Otávio");

            foreach(var item  in Alunos)
            {
                MessageBox.Show(item.ToString());
            }
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar;

            for (int a = 0; a < 20; a++)
            {
                double mediaAluno = 0;
                for (int n = 0; n < 3; n++)
                {
                    auxiliar = Interaction.InputBox($"Digite a Nota {n + 1} do Aluno{a + 1}", "Entrada de Dados");

                    if (auxiliar == "")
                    {
                        break;
                    }
                    if (!double.TryParse(auxiliar, out notas[a,n]))
                    {
                        MessageBox.Show("Numero Invalido");
                        n--;
                    }
                    mediaAluno += notas[a,n];
                }
                mediaAluno = mediaAluno / 3;
                MessageBox.Show($"A média do Aluno {a+1} é: {mediaAluno.ToString("N2")}");
            }
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 exercicio4 = new frmExercicio4();
            exercicio4.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 exercicio5 = new frmExercicio5();
            exercicio5.Show();
        }
        //EXERCICIO 4 ListBox.Itens.Add("") = adicion

    }
}

﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[,] vetor = new string[11, 10];
            string[] gabarito = { "E", "D", "D", "A", "C", "B", "A", "B", "E", "C" };
            string auxiliar;

            for (int i = 0; i < vetor.GetLength(0); i++)
            {
                for (int j = 0; j < vetor.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Resposta da Questão {j + 1} do Aluno {i + 1}", "Entrada de Dados");

                    if (auxiliar == "")
                    {
                        break;
                    }
                    vetor[i, j] = auxiliar.ToUpper();

                    if (vetor[i,j] == gabarito[j])
                    {
                        lbResposta.Items.Add($"A resposta {j + 1} do Aluno {i + 1} está Correta");
                    }
                    else
                    {
                        lbResposta.Items.Add($"A resposta {j + 1} do Aluno {i + 1} está Incorreta");
                    }
                }
            }
        }
    }
}

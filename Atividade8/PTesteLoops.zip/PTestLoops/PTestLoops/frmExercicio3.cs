﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTestar_Click(object sender, EventArgs e)
        {
            string frasemaiuscula = txtTexto.Text.ToUpper();
            char[] vetor = frasemaiuscula.ToCharArray();
            char[] vetor2 = new char[vetor.Length];
            int j = 0;

            for (int i = 0; i < vetor.Length; i++)
                if (!char.IsWhiteSpace(vetor[i]))
                {
                    vetor2[j] = vetor[i];
                    j++;
                }
            string textoSemEspaco = new string(vetor2, 0, j);
            char[] vetor3 = textoSemEspaco.ToCharArray() ;
            Array.Reverse(vetor3);
            string textoReverso = new string(vetor3);

            if(textoSemEspaco.Equals(textoReverso))
            {
                MessageBox.Show("É Palindromo");
            }
            else
            {
                MessageBox.Show("Não é Palindromo");
            }

        }
    }
}

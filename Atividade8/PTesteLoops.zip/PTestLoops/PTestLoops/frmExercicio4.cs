﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double SalarioBruto = 0;
            double B = 0;
            double C = 0;
            double D = 0;

            if (double.TryParse(txtSalario.Text, out double Salario) && Salario > 0 && Salario <= 7000)
            {
                MessageBox.Show("Salário Válido");
            }
            else
            {
                MessageBox.Show("Salário Inválido: Digite Novamente");
                txtSalario.Focus();
            }
            if (double.TryParse(txtGratificacao.Text, out double Gratificacao)) 
            {
                MessageBox.Show("Gratificação Válida");
            }
            else
            {
                MessageBox.Show("Gratificação Inválida: Digite Novamente");
                txtGratificacao.Focus();
            }
            if (double.TryParse(txtProducao.Text, out double Producao))
            {
                MessageBox.Show("Produção Válida");
            }
            else
            {
                MessageBox.Show("Produção : Digite Novamente");
                txtProducao.Focus();
            }
            if (Producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }
            else if (Producao >= 120)
            {
                B = 1;
                C = 1;
                D = 0;
            }
            else if (Producao >= 100)
            {
                B = 1;
                C = 0;
                D = 0;
            }
            else
            {
                B = 0;
                C = 0;
                D = 0;
            }
            SalarioBruto = Salario + (Salario * ((0.05 * B) + (0.1 * C) + (0.1 * D)));

            if (SalarioBruto > 7000)
                if (Producao >= 150 && Gratificacao > 0)
                    SalarioBruto = SalarioBruto ;
                else
                {
                    SalarioBruto = 7000;
                }
            MessageBox.Show($"O Salário Bruto é: R$ {SalarioBruto}");

        }
    }
}

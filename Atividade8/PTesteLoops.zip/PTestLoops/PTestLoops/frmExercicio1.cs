﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            double espaco = 0;

            char[] vetor = rchtxtFrase.Text.ToCharArray();

            foreach (char espacos in vetor)
            {
                if (char.IsWhiteSpace(espacos))
                {
                    espaco++;
                }

            }
            MessageBox.Show($"o texto tem {espaco} espaço(s)");
        }

        private void btnLetra_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text.ToString();
            string frasemaiuscula = frase.ToUpper();
            char[] vetor = frasemaiuscula.ToCharArray();
            double cont = 0;

            foreach (char letraR in vetor)
            {
                if (letraR == 'R')
                {
                    cont++;
                }
            }
            MessageBox.Show($"o texto tem {cont} letra(s) R");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            double cont = 0;

            char[] vetor = rchtxtFrase.Text.ToCharArray();

            for (int i = 0; i < (vetor.Length - 1); i++)
                if (vetor[i+1] == vetor[i])
                    cont++;
            MessageBox.Show($"o texto tem {cont} par(es) de letra(s) iguais");

        }
    }
}

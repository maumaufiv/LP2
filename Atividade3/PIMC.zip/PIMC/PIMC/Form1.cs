﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso) || (peso <= 0))
            {
                MessageBox.Show("Valor Inválido");
                txtPeso.Focus();
            }
        }

        private void txtAlt_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAlt.Text, out altura))
            {
                MessageBox.Show("Valor Invalido");
                txtAlt.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura,2));
            txtIMC.Text = imc.ToString();
            imc = Math.Round(imc, 2);

            if (imc < 18.5)
                MessageBox.Show("MAGREZA");
            else
                if (imc <= 24.90)
                MessageBox.Show("NORMAL");
            else
                if (imc <= 29.90)
                MessageBox.Show("SOBREPESO");
            else
                if (imc <= 39.90)
                MessageBox.Show("OBESIDADE");
            else
                MessageBox.Show("OBESIDADE GRAVE");

        }
        public Form1()
        {
            InitializeComponent();
        }
    }
}

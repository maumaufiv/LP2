﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            int i = 0;
            double Numero = 0;

            char[] vetor = rchtxtPalavra.Text.ToCharArray();

            while(i < vetor.Length)
            {
                if (char.IsNumber(vetor[i]))
                {
                    Numero++;
                }
                i++;
            }
            MessageBox.Show($"o texto tem {Numero} numero");

        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int i = 0;
            double Espaco = 0;

            char[] vetor = rchtxtPalavra.Text.ToCharArray();

            for(i = 0; i < vetor.Length; i++)
            {
                if (char.IsWhiteSpace(vetor[i]))
                {
                    Espaco++;
                }
            }
            MessageBox.Show($"o texto tem {Espaco} espaços");
        }

        private void btnAlfabeto_Click(object sender, EventArgs e)
        {
            double letra = 0;

            char[] vetor = rchtxtPalavra.Text.ToCharArray();

            foreach(char letras in vetor)
            {
                if (char.IsLetter(letras))
                {
                    letra++;
                }
                    
            }
            MessageBox.Show($"o texto tem {letra} letras");
        }
    }
}

﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtPalavra = new System.Windows.Forms.RichTextBox();
            this.btnNumero = new System.Windows.Forms.Button();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnAlfabeto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtPalavra
            // 
            this.rchtxtPalavra.Location = new System.Drawing.Point(271, 86);
            this.rchtxtPalavra.Name = "rchtxtPalavra";
            this.rchtxtPalavra.Size = new System.Drawing.Size(305, 96);
            this.rchtxtPalavra.TabIndex = 0;
            this.rchtxtPalavra.Text = "";
            // 
            // btnNumero
            // 
            this.btnNumero.Location = new System.Drawing.Point(235, 253);
            this.btnNumero.Name = "btnNumero";
            this.btnNumero.Size = new System.Drawing.Size(129, 55);
            this.btnNumero.TabIndex = 1;
            this.btnNumero.Text = "Quantos Numeros";
            this.btnNumero.UseVisualStyleBackColor = true;
            this.btnNumero.Click += new System.EventHandler(this.btnNumero_Click);
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(376, 253);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(129, 55);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "Quantos Espaços";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnAlfabeto
            // 
            this.btnAlfabeto.Location = new System.Drawing.Point(520, 253);
            this.btnAlfabeto.Name = "btnAlfabeto";
            this.btnAlfabeto.Size = new System.Drawing.Size(129, 55);
            this.btnAlfabeto.TabIndex = 3;
            this.btnAlfabeto.Text = "Quantas Letras";
            this.btnAlfabeto.UseVisualStyleBackColor = true;
            this.btnAlfabeto.Click += new System.EventHandler(this.btnAlfabeto_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAlfabeto);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.btnNumero);
            this.Controls.Add(this.rchtxtPalavra);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtPalavra;
        private System.Windows.Forms.Button btnNumero;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnAlfabeto;
    }
}
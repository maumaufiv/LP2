﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void txtladoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtladoC.Text, out ladoC) || (ladoC < 0))
            {
                MessageBox.Show("Valor Inválido");
                txtladoC.Focus();
            }
        }

        private void textladoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtladoB.Text, out ladoB) || (ladoB < 0))
            {
                MessageBox.Show("Valor Inválido");
                txtladoB.Focus();
            }
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (((ladoA + ladoB) > ladoC) && ((ladoA + ladoC) > ladoB) && ((ladoB + ladoC) > ladoA))
            {
                MessageBox.Show("É um triângulo");
            }
            if ((ladoA == ladoB) && (ladoA == ladoC))
            {
                MessageBox.Show("Equilátero");
            }
            else
                if ((ladoA == ladoB) && (ladoA == ladoC) && (ladoB == ladoC))
            {
                MessageBox.Show("Isóceles");
            }
            else
            {
                MessageBox.Show("Escaleno");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtladoA.Text, out ladoA) || ladoA < 0)
            {
                MessageBox.Show("Valor Inválido");
                txtladoA.Focus();
            }
        } 
        public Form1()
        {
            InitializeComponent();
        }
    }
}
